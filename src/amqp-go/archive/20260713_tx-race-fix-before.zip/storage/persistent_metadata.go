package storage

import (
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/fxamacker/cbor/v2"
	"github.com/maxpert/amqp-go/interfaces"
	"github.com/maxpert/amqp-go/protocol"
)

const (
	MetadataDir         = "metadata"
	ExchangesDir        = "exchanges"
	QueuesDir           = "queues"
	BindingsDir         = "bindings"
	ExchangeBindingsDir = "exchange_bindings"
	ConsumersDir        = "consumers"
	FileExtension       = ".cbor"
	TempFileExtension   = ".tmp"
	DeliveryTagFile     = "delivery_tag"
)

// PersistentMetadataStore implements persistent metadata storage using CBOR binary format
// Phase 3: Simple, debuggable file-based metadata
// Phase 6D: In-memory cache for hot path optimization
// Phase 6F: Migrated from JSON to CBOR for 2-3x faster serialization
// Phase 6H: Added binding cache for routing performance
type PersistentMetadataStore struct {
	baseDir string
	mutex   sync.RWMutex

	// In-memory cache for hot path (Phase 6D)
	exchangeCache sync.Map // name -> *protocol.Exchange
	queueCache    sync.Map // name -> *protocol.Queue

	// Binding cache (Phase 6H) - critical for routing performance
	bindingCache          sync.Map // "queue:exchange:key" -> *interfaces.QueueBinding
	queueBindingsCache    sync.Map // queueName -> []*interfaces.QueueBinding
	exchangeBindingsCache sync.Map // exchangeName -> []*interfaces.QueueBinding

	// Exchange-to-exchange binding cache
	exchBindingCache      sync.Map // "source:dest:key" -> *interfaces.ExchangeBinding
	exchBindingsFromCache sync.Map // source -> []*interfaces.ExchangeBinding

	cacheEnabled bool
}

// NewPersistentMetadataStore creates a new persistent metadata store
func NewPersistentMetadataStore(dataDir string) (*PersistentMetadataStore, error) {
	baseDir := filepath.Join(dataDir, MetadataDir)

	// Create directory structure
	dirs := []string{
		filepath.Join(baseDir, ExchangesDir),
		filepath.Join(baseDir, QueuesDir),
		filepath.Join(baseDir, BindingsDir),
		filepath.Join(baseDir, ExchangeBindingsDir),
		filepath.Join(baseDir, ConsumersDir),
	}

	for _, dir := range dirs {
		if err := os.MkdirAll(dir, 0755); err != nil {
			return nil, fmt.Errorf("failed to create metadata directory %s: %w", dir, err)
		}
	}

	store := &PersistentMetadataStore{
		baseDir:      baseDir,
		cacheEnabled: true, // Enable cache - investigating consumer bottleneck at high load
	}

	// Pre-populate cache on startup (if enabled)
	if store.cacheEnabled {
		store.loadCacheFromDisk()
	}

	return store, nil
}

// loadCacheFromDisk pre-populates the cache on startup
func (pm *PersistentMetadataStore) loadCacheFromDisk() {
	// Load all exchanges into cache
	exchangesDir := filepath.Join(pm.baseDir, ExchangesDir)
	if entries, err := os.ReadDir(exchangesDir); err == nil {
		for _, entry := range entries {
			if !entry.IsDir() && strings.HasSuffix(entry.Name(), FileExtension) {
				name := strings.TrimSuffix(entry.Name(), FileExtension)
				if exchange, err := pm.loadExchangeFromDisk(name); err == nil {
					pm.exchangeCache.Store(name, exchange)
				}
			}
		}
	}

	// Load all queues into cache
	queuesDir := filepath.Join(pm.baseDir, QueuesDir)
	if entries, err := os.ReadDir(queuesDir); err == nil {
		for _, entry := range entries {
			if !entry.IsDir() && strings.HasSuffix(entry.Name(), FileExtension) {
				name := strings.TrimSuffix(entry.Name(), FileExtension)
				if queue, err := pm.loadQueueFromDisk(name); err == nil {
					pm.queueCache.Store(name, queue)
				}
			}
		}
	}

	// Load all bindings into cache (Phase 6H)
	if bindings, err := pm.loadBindingsFromDisk(); err == nil {
		// Build per-queue and per-exchange indexes
		queueBindings := make(map[string][]*interfaces.QueueBinding)
		exchangeBindings := make(map[string][]*interfaces.QueueBinding)

		for _, binding := range bindings {
			// Cache individual binding
			cacheKey := makeBindingCacheKey(binding.QueueName, binding.ExchangeName, binding.RoutingKey)
			pm.bindingCache.Store(cacheKey, binding)

			// Index by queue
			queueBindings[binding.QueueName] = append(queueBindings[binding.QueueName], binding)

			// Index by exchange
			exchangeBindings[binding.ExchangeName] = append(exchangeBindings[binding.ExchangeName], binding)
		}

		// Store indexed caches
		for queueName, bindings := range queueBindings {
			pm.queueBindingsCache.Store(queueName, bindings)
		}
		for exchangeName, bindings := range exchangeBindings {
			pm.exchangeBindingsCache.Store(exchangeName, bindings)
		}

		// Load all exchange-to-exchange bindings into cache
		if exchBindings, err := pm.loadExchangeBindingsFromDisk(); err == nil {
			fromIndex := make(map[string][]*interfaces.ExchangeBinding)
			for _, eb := range exchBindings {
				cacheKey := makeExchangeBindingCacheKey(eb.Source, eb.Destination, eb.RoutingKey)
				pm.exchBindingCache.Store(cacheKey, eb)
				fromIndex[eb.Source] = append(fromIndex[eb.Source], eb)
			}
			for source, bindings := range fromIndex {
				pm.exchBindingsFromCache.Store(source, bindings)
			}
		}
	}
}

// makeBindingCacheKey creates a unique cache key for a binding
func makeBindingCacheKey(queueName, exchangeName, routingKey string) string {
	return fmt.Sprintf("%s:%s:%s", queueName, exchangeName, routingKey)
}

// loadBindingsFromDisk loads all bindings from disk (helper for cache preload)
func (pm *PersistentMetadataStore) loadBindingsFromDisk() ([]*interfaces.QueueBinding, error) {
	dir := filepath.Join(pm.baseDir, BindingsDir)
	files, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return []*interfaces.QueueBinding{}, nil
		}
		return nil, fmt.Errorf("failed to read bindings directory: %w", err)
	}

	bindings := make([]*interfaces.QueueBinding, 0, len(files))
	for _, file := range files {
		if file.IsDir() || !strings.HasSuffix(file.Name(), FileExtension) {
			continue
		}

		path := filepath.Join(dir, file.Name())
		data, err := os.ReadFile(path)
		if err != nil {
			continue // Skip unreadable files
		}

		var binding interfaces.QueueBinding
		if err := cbor.Unmarshal(data, &binding); err != nil {
			continue // Skip corrupted files
		}

		bindings = append(bindings, &binding)
	}

	return bindings, nil
}

// atomicWrite writes data to a file atomically and durably using a
// temp file + fsync + rename + directory fsync sequence.
//
// Durability (SQ-3): plain os.WriteFile + os.Rename leaves both the file's data
// and the rename itself in the page cache. On a crash or power loss before the
// OS flushes, topology (queues/exchanges/bindings) can vanish, or the rename
// can land pointing at a zero-length or partially written file on some
// filesystems. To prevent that we:
//  1. write the temp file, fsync it (data durable) and close it,
//  2. rename it into place (atomic replace),
//  3. fsync the parent directory so the rename entry is durable.
//
// This is a declare-time path (not the message hot path), so correctness is
// favored over speed. There is exactly one file fsync and one directory fsync
// per write — no more syncing than required.
func (pm *PersistentMetadataStore) atomicWrite(path string, data []byte) error {
	// Ensure parent directory exists
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return fmt.Errorf("failed to create directory: %w", err)
	}

	// Write to temp file and fsync it before renaming so its contents are on
	// stable storage. Any error cleans up the temp file so no .tmp is left
	// behind and the failure is surfaced (never swallowed).
	tempPath := path + TempFileExtension
	f, err := os.OpenFile(tempPath, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
	if err != nil {
		return fmt.Errorf("failed to create temp file: %w", err)
	}
	if _, err := f.Write(data); err != nil {
		_ = f.Close()
		_ = os.Remove(tempPath)
		return fmt.Errorf("failed to write temp file: %w", err)
	}
	if err := f.Sync(); err != nil {
		_ = f.Close()
		_ = os.Remove(tempPath)
		return fmt.Errorf("failed to fsync temp file: %w", err)
	}
	if err := f.Close(); err != nil {
		_ = os.Remove(tempPath)
		return fmt.Errorf("failed to close temp file: %w", err)
	}

	// Atomic rename
	if err := os.Rename(tempPath, path); err != nil {
		_ = os.Remove(tempPath) // Clean up on failure
		return fmt.Errorf("failed to rename temp file: %w", err)
	}

	// fsync the parent directory so the rename survives a crash/power loss.
	if err := syncDir(dir); err != nil {
		return fmt.Errorf("failed to fsync directory: %w", err)
	}

	return nil
}

// StoreExchange persists an exchange to disk and updates cache
func (pm *PersistentMetadataStore) StoreExchange(exchange *protocol.Exchange) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	data, err := cbor.Marshal(exchange)
	if err != nil {
		return fmt.Errorf("failed to marshal exchange: %w", err)
	}

	path := filepath.Join(pm.baseDir, ExchangesDir, exchange.Name+FileExtension)
	if err := pm.atomicWrite(path, data); err != nil {
		return err
	}

	// Update cache (Phase 6D)
	if pm.cacheEnabled {
		pm.exchangeCache.Store(exchange.Name, exchange)
	}

	return nil
}

// GetExchange loads an exchange from cache or disk
func (pm *PersistentMetadataStore) GetExchange(name string) (*protocol.Exchange, error) {
	// Try cache first (Phase 6D: lock-free hot path!)
	if pm.cacheEnabled {
		if cached, ok := pm.exchangeCache.Load(name); ok {
			return cached.(*protocol.Exchange), nil
		}
	}

	// Cache miss - load from disk
	return pm.loadExchangeFromDisk(name)
}

// loadExchangeFromDisk loads an exchange from disk (cache miss path)
func (pm *PersistentMetadataStore) loadExchangeFromDisk(name string) (*protocol.Exchange, error) {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	path := filepath.Join(pm.baseDir, ExchangesDir, name+FileExtension)
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, interfaces.ErrExchangeNotFound
		}
		return nil, fmt.Errorf("failed to read exchange file: %w", err)
	}

	var exchange protocol.Exchange
	if err := cbor.Unmarshal(data, &exchange); err != nil {
		return nil, fmt.Errorf("failed to unmarshal exchange: %w", err)
	}

	// Update cache on load (Phase 6D)
	if pm.cacheEnabled {
		pm.exchangeCache.Store(name, &exchange)
	}

	return &exchange, nil
}

// DeleteExchange removes an exchange file and cache entry
func (pm *PersistentMetadataStore) DeleteExchange(name string) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	path := filepath.Join(pm.baseDir, ExchangesDir, name+FileExtension)
	if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("failed to delete exchange file: %w", err)
	}

	// Remove from cache (Phase 6D)
	if pm.cacheEnabled {
		pm.exchangeCache.Delete(name)
	}

	return nil
}

// ListExchanges returns all exchanges
func (pm *PersistentMetadataStore) ListExchanges() ([]*protocol.Exchange, error) {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	dir := filepath.Join(pm.baseDir, ExchangesDir)
	files, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return []*protocol.Exchange{}, nil
		}
		return nil, fmt.Errorf("failed to read exchanges directory: %w", err)
	}

	exchanges := make([]*protocol.Exchange, 0, len(files))
	for _, file := range files {
		if file.IsDir() || !strings.HasSuffix(file.Name(), FileExtension) {
			continue
		}

		name := strings.TrimSuffix(file.Name(), FileExtension)
		exchange, err := pm.GetExchange(name)
		if err != nil {
			continue // Skip corrupted files
		}
		exchanges = append(exchanges, exchange)
	}

	return exchanges, nil
}

// StoreQueue persists a queue to disk and updates cache
func (pm *PersistentMetadataStore) StoreQueue(queue *protocol.Queue) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	data, err := cbor.Marshal(queue)
	if err != nil {
		return fmt.Errorf("failed to marshal queue: %w", err)
	}

	path := filepath.Join(pm.baseDir, QueuesDir, queue.Name+FileExtension)
	if err := pm.atomicWrite(path, data); err != nil {
		return err
	}

	// Update cache (Phase 6D)
	if pm.cacheEnabled {
		pm.queueCache.Store(queue.Name, queue)
	}

	return nil
}

// GetQueue loads a queue from cache or disk
func (pm *PersistentMetadataStore) GetQueue(name string) (*protocol.Queue, error) {
	// Try cache first (Phase 6D: lock-free hot path!)
	if pm.cacheEnabled {
		if cached, ok := pm.queueCache.Load(name); ok {
			return cached.(*protocol.Queue), nil
		}
	}

	// Cache miss - load from disk
	return pm.loadQueueFromDisk(name)
}

// loadQueueFromDisk loads a queue from disk (cache miss path)
func (pm *PersistentMetadataStore) loadQueueFromDisk(name string) (*protocol.Queue, error) {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	path := filepath.Join(pm.baseDir, QueuesDir, name+FileExtension)
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, interfaces.ErrQueueNotFound
		}
		return nil, fmt.Errorf("failed to read queue file: %w", err)
	}

	var queue protocol.Queue
	if err := cbor.Unmarshal(data, &queue); err != nil {
		return nil, fmt.Errorf("failed to unmarshal queue: %w", err)
	}

	// Update cache on load (Phase 6D)
	if pm.cacheEnabled {
		pm.queueCache.Store(name, &queue)
	}

	return &queue, nil
}

// DeleteQueue removes a queue file and cache entry
func (pm *PersistentMetadataStore) DeleteQueue(name string) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	path := filepath.Join(pm.baseDir, QueuesDir, name+FileExtension)
	if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("failed to delete queue file: %w", err)
	}

	// Remove from cache (Phase 6D)
	if pm.cacheEnabled {
		pm.queueCache.Delete(name)
	}

	return nil
}

// ListQueues returns all queues
func (pm *PersistentMetadataStore) ListQueues() ([]*protocol.Queue, error) {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	dir := filepath.Join(pm.baseDir, QueuesDir)
	files, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return []*protocol.Queue{}, nil
		}
		return nil, fmt.Errorf("failed to read queues directory: %w", err)
	}

	queues := make([]*protocol.Queue, 0, len(files))
	for _, file := range files {
		if file.IsDir() || !strings.HasSuffix(file.Name(), FileExtension) {
			continue
		}

		name := strings.TrimSuffix(file.Name(), FileExtension)
		queue, err := pm.GetQueue(name)
		if err != nil {
			continue // Skip corrupted files
		}
		queues = append(queues, queue)
	}

	return queues, nil
}

// makeBindingFilename creates a unique filename for a binding
func makeBindingFilename(queueName, exchangeName, routingKey string) string {
	// Replace special characters to make it filesystem-safe
	safe := func(s string) string {
		s = strings.ReplaceAll(s, "/", "_")
		s = strings.ReplaceAll(s, "\\", "_")
		s = strings.ReplaceAll(s, ":", "_")
		s = strings.ReplaceAll(s, "*", "_")
		s = strings.ReplaceAll(s, "?", "_")
		s = strings.ReplaceAll(s, "<", "_")
		s = strings.ReplaceAll(s, ">", "_")
		s = strings.ReplaceAll(s, "|", "_")
		return s
	}

	return fmt.Sprintf("%s_%s_%s%s",
		safe(queueName),
		safe(exchangeName),
		safe(routingKey),
		FileExtension)
}

// StoreBinding persists a binding to disk and updates cache
func (pm *PersistentMetadataStore) StoreBinding(queueName, exchangeName, routingKey string, arguments map[string]interface{}) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	binding := &interfaces.QueueBinding{
		QueueName:    queueName,
		ExchangeName: exchangeName,
		RoutingKey:   routingKey,
		Arguments:    arguments,
	}

	data, err := cbor.Marshal(binding)
	if err != nil {
		return fmt.Errorf("failed to marshal binding: %w", err)
	}

	filename := makeBindingFilename(queueName, exchangeName, routingKey)
	path := filepath.Join(pm.baseDir, BindingsDir, filename)
	if err := pm.atomicWrite(path, data); err != nil {
		return err
	}

	// Update cache (Phase 6H)
	if pm.cacheEnabled {
		cacheKey := makeBindingCacheKey(queueName, exchangeName, routingKey)
		pm.bindingCache.Store(cacheKey, binding)

		// Invalidate queue and exchange binding caches to force rebuild on next access
		pm.queueBindingsCache.Delete(queueName)
		pm.exchangeBindingsCache.Delete(exchangeName)
	}

	return nil
}

// GetBinding loads a binding from cache or disk
func (pm *PersistentMetadataStore) GetBinding(queueName, exchangeName, routingKey string) (*interfaces.QueueBinding, error) {
	// Try cache first (Phase 6H: lock-free hot path!)
	if pm.cacheEnabled {
		cacheKey := makeBindingCacheKey(queueName, exchangeName, routingKey)
		if cached, ok := pm.bindingCache.Load(cacheKey); ok {
			return cached.(*interfaces.QueueBinding), nil
		}
	}

	// Cache miss - load from disk
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	filename := makeBindingFilename(queueName, exchangeName, routingKey)
	path := filepath.Join(pm.baseDir, BindingsDir, filename)

	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, interfaces.ErrBindingNotFound
		}
		return nil, fmt.Errorf("failed to read binding file: %w", err)
	}

	var binding interfaces.QueueBinding
	if err := cbor.Unmarshal(data, &binding); err != nil {
		return nil, fmt.Errorf("failed to unmarshal binding: %w", err)
	}

	// Update cache on load (Phase 6H)
	if pm.cacheEnabled {
		cacheKey := makeBindingCacheKey(queueName, exchangeName, routingKey)
		pm.bindingCache.Store(cacheKey, &binding)
	}

	return &binding, nil
}

// DeleteBinding removes a binding file and cache entry
func (pm *PersistentMetadataStore) DeleteBinding(queueName, exchangeName, routingKey string) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	filename := makeBindingFilename(queueName, exchangeName, routingKey)
	path := filepath.Join(pm.baseDir, BindingsDir, filename)

	if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("failed to delete binding file: %w", err)
	}

	// Remove from cache (Phase 6H)
	if pm.cacheEnabled {
		cacheKey := makeBindingCacheKey(queueName, exchangeName, routingKey)
		pm.bindingCache.Delete(cacheKey)

		// Invalidate queue and exchange binding caches to force rebuild
		pm.queueBindingsCache.Delete(queueName)
		pm.exchangeBindingsCache.Delete(exchangeName)
	}

	return nil
}

// ListBindings returns all bindings
func (pm *PersistentMetadataStore) ListBindings() ([]*interfaces.QueueBinding, error) {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	dir := filepath.Join(pm.baseDir, BindingsDir)
	files, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return []*interfaces.QueueBinding{}, nil
		}
		return nil, fmt.Errorf("failed to read bindings directory: %w", err)
	}

	bindings := make([]*interfaces.QueueBinding, 0, len(files))
	for _, file := range files {
		if file.IsDir() || !strings.HasSuffix(file.Name(), FileExtension) {
			continue
		}

		path := filepath.Join(dir, file.Name())
		data, err := os.ReadFile(path)
		if err != nil {
			continue // Skip unreadable files
		}

		var binding interfaces.QueueBinding
		if err := cbor.Unmarshal(data, &binding); err != nil {
			continue // Skip corrupted files
		}

		bindings = append(bindings, &binding)
	}

	return bindings, nil
}

// GetQueueBindings returns all bindings for a specific queue (cached)
func (pm *PersistentMetadataStore) GetQueueBindings(queueName string) ([]*interfaces.QueueBinding, error) {
	// Try cache first (Phase 6H: O(1) lookup instead of O(n) scan!)
	if pm.cacheEnabled {
		if cached, ok := pm.queueBindingsCache.Load(queueName); ok {
			return cached.([]*interfaces.QueueBinding), nil
		}
	}

	// Cache miss - load all bindings and rebuild index
	allBindings, err := pm.ListBindings()
	if err != nil {
		return nil, err
	}

	result := make([]*interfaces.QueueBinding, 0)
	for _, binding := range allBindings {
		if binding.QueueName == queueName {
			result = append(result, binding)
		}
	}

	// Update cache with result (Phase 6H)
	if pm.cacheEnabled {
		pm.queueBindingsCache.Store(queueName, result)
	}

	return result, nil
}

// GetExchangeBindings returns all bindings for a specific exchange (cached)
func (pm *PersistentMetadataStore) GetExchangeBindings(exchangeName string) ([]*interfaces.QueueBinding, error) {
	// Try cache first (Phase 6H: O(1) lookup instead of O(n) scan!)
	if pm.cacheEnabled {
		if cached, ok := pm.exchangeBindingsCache.Load(exchangeName); ok {
			return cached.([]*interfaces.QueueBinding), nil
		}
	}

	// Cache miss - load all bindings and rebuild index
	allBindings, err := pm.ListBindings()
	if err != nil {
		return nil, err
	}

	result := make([]*interfaces.QueueBinding, 0)
	for _, binding := range allBindings {
		if binding.ExchangeName == exchangeName {
			result = append(result, binding)
		}
	}

	// Update cache with result (Phase 6H)
	if pm.cacheEnabled {
		pm.exchangeBindingsCache.Store(exchangeName, result)
	}

	return result, nil
}

// makeExchangeBindingCacheKey creates a unique cache key for an exchange-to-exchange binding
func makeExchangeBindingCacheKey(source, destination, routingKey string) string {
	return fmt.Sprintf("%s:%s:%s", source, destination, routingKey)
}

// makeExchangeBindingFilename creates a unique filename for an exchange-to-exchange binding
func makeExchangeBindingFilename(source, destination, routingKey string) string {
	safe := func(s string) string {
		s = strings.ReplaceAll(s, "/", "_")
		s = strings.ReplaceAll(s, "\\", "_")
		s = strings.ReplaceAll(s, ":", "_")
		s = strings.ReplaceAll(s, "*", "_")
		s = strings.ReplaceAll(s, "?", "_")
		s = strings.ReplaceAll(s, "<", "_")
		s = strings.ReplaceAll(s, ">", "_")
		s = strings.ReplaceAll(s, "|", "_")
		return s
	}

	return fmt.Sprintf("%s_%s_%s%s",
		safe(source),
		safe(destination),
		safe(routingKey),
		FileExtension)
}

// loadExchangeBindingsFromDisk loads all exchange-to-exchange bindings from disk
func (pm *PersistentMetadataStore) loadExchangeBindingsFromDisk() ([]*interfaces.ExchangeBinding, error) {
	dir := filepath.Join(pm.baseDir, ExchangeBindingsDir)
	files, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return []*interfaces.ExchangeBinding{}, nil
		}
		return nil, fmt.Errorf("failed to read exchange bindings directory: %w", err)
	}

	bindings := make([]*interfaces.ExchangeBinding, 0, len(files))
	for _, file := range files {
		if file.IsDir() || !strings.HasSuffix(file.Name(), FileExtension) {
			continue
		}

		path := filepath.Join(dir, file.Name())
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}

		var binding interfaces.ExchangeBinding
		if err := cbor.Unmarshal(data, &binding); err != nil {
			continue
		}

		bindings = append(bindings, &binding)
	}

	return bindings, nil
}

// StoreExchangeBinding persists an exchange-to-exchange binding to disk and updates cache
func (pm *PersistentMetadataStore) StoreExchangeBinding(source, destination, routingKey string, arguments map[string]interface{}) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	binding := &interfaces.ExchangeBinding{
		Source:      source,
		Destination: destination,
		RoutingKey:  routingKey,
		Arguments:   arguments,
	}

	data, err := cbor.Marshal(binding)
	if err != nil {
		return fmt.Errorf("failed to marshal exchange binding: %w", err)
	}

	filename := makeExchangeBindingFilename(source, destination, routingKey)
	path := filepath.Join(pm.baseDir, ExchangeBindingsDir, filename)
	if err := pm.atomicWrite(path, data); err != nil {
		return err
	}

	if pm.cacheEnabled {
		cacheKey := makeExchangeBindingCacheKey(source, destination, routingKey)
		pm.exchBindingCache.Store(cacheKey, binding)
		pm.exchBindingsFromCache.Delete(source)
	}

	return nil
}

// DeleteExchangeBinding removes an exchange-to-exchange binding from disk and cache
func (pm *PersistentMetadataStore) DeleteExchangeBinding(source, destination, routingKey string) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	filename := makeExchangeBindingFilename(source, destination, routingKey)
	path := filepath.Join(pm.baseDir, ExchangeBindingsDir, filename)

	if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("failed to delete exchange binding file: %w", err)
	}

	if pm.cacheEnabled {
		cacheKey := makeExchangeBindingCacheKey(source, destination, routingKey)
		pm.exchBindingCache.Delete(cacheKey)
		pm.exchBindingsFromCache.Delete(source)
	}

	return nil
}

// GetExchangeBindingsFrom returns all exchange-to-exchange bindings from the given source exchange
func (pm *PersistentMetadataStore) GetExchangeBindingsFrom(source string) ([]*interfaces.ExchangeBinding, error) {
	if pm.cacheEnabled {
		if cached, ok := pm.exchBindingsFromCache.Load(source); ok {
			return cached.([]*interfaces.ExchangeBinding), nil
		}
	}

	allBindings, err := pm.loadExchangeBindingsFromDisk()
	if err != nil {
		return nil, err
	}

	result := make([]*interfaces.ExchangeBinding, 0)
	for _, binding := range allBindings {
		if binding.Source == source {
			result = append(result, binding)
		}
	}

	if pm.cacheEnabled {
		pm.exchBindingsFromCache.Store(source, result)
	}

	return result, nil
}

// StoreConsumer is a no-op - consumers are runtime state and should not be persisted
// Consumers contain channel pointers, goroutines (Messages chan, Cancel chan), and other
// non-serializable state that causes circular references when attempting JSON marshalling.
// Consumer registration is ephemeral - they're recreated on each connection.
func (pm *PersistentMetadataStore) StoreConsumer(queueName, consumerTag string, consumer *protocol.Consumer) error {
	// No-op: Consumers are not persisted
	return nil
}

// GetConsumer loads a consumer from disk
func (pm *PersistentMetadataStore) GetConsumer(queueName, consumerTag string) (*protocol.Consumer, error) {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	path := filepath.Join(pm.baseDir, ConsumersDir, queueName, consumerTag+FileExtension)
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, interfaces.ErrConsumerNotFound
		}
		return nil, fmt.Errorf("failed to read consumer file: %w", err)
	}

	var consumer protocol.Consumer
	if err := cbor.Unmarshal(data, &consumer); err != nil {
		return nil, fmt.Errorf("failed to unmarshal consumer: %w", err)
	}

	return &consumer, nil
}

// DeleteConsumer removes a consumer file
func (pm *PersistentMetadataStore) DeleteConsumer(queueName, consumerTag string) error {
	pm.mutex.Lock()
	defer pm.mutex.Unlock()

	path := filepath.Join(pm.baseDir, ConsumersDir, queueName, consumerTag+FileExtension)
	if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("failed to delete consumer file: %w", err)
	}

	return nil
}

// GetQueueConsumers returns all consumers for a queue
func (pm *PersistentMetadataStore) GetQueueConsumers(queueName string) ([]*protocol.Consumer, error) {
	pm.mutex.RLock()
	defer pm.mutex.RUnlock()

	queueDir := filepath.Join(pm.baseDir, ConsumersDir, queueName)
	files, err := os.ReadDir(queueDir)
	if err != nil {
		if os.IsNotExist(err) {
			return []*protocol.Consumer{}, nil
		}
		return nil, fmt.Errorf("failed to read consumers directory: %w", err)
	}

	consumers := make([]*protocol.Consumer, 0, len(files))
	for _, file := range files {
		if file.IsDir() || !strings.HasSuffix(file.Name(), FileExtension) {
			continue
		}

		consumerTag := strings.TrimSuffix(file.Name(), FileExtension)
		consumer, err := pm.GetConsumer(queueName, consumerTag)
		if err != nil {
			continue // Skip corrupted files
		}
		consumers = append(consumers, consumer)
	}

	return consumers, nil
}

// LoadAllMetadata loads all metadata from disk for recovery
func (pm *PersistentMetadataStore) LoadAllMetadata() (
	exchanges []*protocol.Exchange,
	queues []*protocol.Queue,
	bindings []*interfaces.QueueBinding,
	consumers map[string][]*protocol.Consumer,
	err error,
) {
	consumers = make(map[string][]*protocol.Consumer)

	// Load exchanges
	exchanges, err = pm.ListExchanges()
	if err != nil {
		return nil, nil, nil, nil, fmt.Errorf("failed to load exchanges: %w", err)
	}

	// Load queues
	queues, err = pm.ListQueues()
	if err != nil {
		return nil, nil, nil, nil, fmt.Errorf("failed to load queues: %w", err)
	}

	// Load bindings
	bindings, err = pm.ListBindings()
	if err != nil {
		return nil, nil, nil, nil, fmt.Errorf("failed to load bindings: %w", err)
	}

	// Load consumers for each queue
	for _, queue := range queues {
		queueConsumers, err := pm.GetQueueConsumers(queue.Name)
		if err != nil {
			continue // Skip errors for individual queues
		}
		if len(queueConsumers) > 0 {
			consumers[queue.Name] = queueConsumers
		}
	}

	return exchanges, queues, bindings, consumers, nil
}

func (pm *PersistentMetadataStore) SaveDeliveryTagCounter(tag uint64) error {
	data := make([]byte, 8)
	binary.BigEndian.PutUint64(data, tag)
	path := filepath.Join(pm.baseDir, DeliveryTagFile)
	pm.mutex.Lock()
	defer pm.mutex.Unlock()
	return pm.atomicWrite(path, data)
}

func (pm *PersistentMetadataStore) LoadDeliveryTagCounter() (uint64, error) {
	path := filepath.Join(pm.baseDir, DeliveryTagFile)
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return 0, nil
		}
		return 0, fmt.Errorf("failed to read delivery tag counter: %w", err)
	}
	if len(data) < 8 {
		return 0, nil
	}
	return binary.BigEndian.Uint64(data), nil
}

// Close closes the metadata store (no-op for JSON files)
func (pm *PersistentMetadataStore) Close() error {
	return nil
}

// Helper to read a JSON file
func readJSONFile(path string, v interface{}) error {
	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer file.Close()

	data, err := io.ReadAll(file)
	if err != nil {
		return err
	}

	return cbor.Unmarshal(data, v)
}
