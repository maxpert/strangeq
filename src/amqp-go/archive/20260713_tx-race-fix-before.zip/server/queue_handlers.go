package server

import (
	"errors"
	"fmt"

	"github.com/maxpert/amqp-go/broker"
	amqperrors "github.com/maxpert/amqp-go/errors"
	"github.com/maxpert/amqp-go/interfaces"
	"github.com/maxpert/amqp-go/protocol"
	"go.uber.org/zap"
)

// resolveQueueName resolves an empty queue name to the channel's "current
// queue" (the last queue declared on the channel), per AMQP 0.9.1 spec
// "queue-known" rule. Returns the resolved name, or an error if the name
// is empty and no queue was previously declared on the channel (spec:
// "this will result in a 502 (syntax error) channel exception").
func resolveQueueName(conn *protocol.Connection, channelID uint16, queueName string) (string, error) {
	if queueName != "" {
		return queueName, nil
	}
	// Empty name: resolve to the channel's current queue
	if val, exists := conn.Channels.Load(channelID); exists {
		ch := val.(*protocol.Channel)
		ch.Mutex.RLock()
		current := ch.CurrentQueue
		ch.Mutex.RUnlock()
		if current != "" {
			return current, nil
		}
	}
	return "", fmt.Errorf("no queue name specified and no current queue on channel %d (spec: 502 syntax error)", channelID)
}

// processQueueMethod handles queue-related methods
func (s *Server) processQueueMethod(conn *protocol.Connection, channelID uint16, methodID uint16, payload []byte) error {
	switch methodID {
	case protocol.QueueDeclare: // Method ID 10 for queue class
		return s.handleQueueDeclare(conn, channelID, payload)
	case protocol.QueueBind: // Method ID 20 for queue class
		return s.handleQueueBind(conn, channelID, payload)
	case protocol.QueueUnbind: // Method ID 50 for queue class
		return s.handleQueueUnbind(conn, channelID, payload)
	case protocol.QueuePurge: // Method ID 30 for queue class
		return s.handleQueuePurge(conn, channelID, payload)
	case protocol.QueueDelete: // Method ID 40 for queue class
		return s.handleQueueDelete(conn, channelID, payload)
	default:
		s.Log.Warn("Unknown queue method ID",
			zap.Uint16("method_id", methodID),
			zap.Uint16("channel_id", channelID),
			zap.String("connection_id", conn.ID))
		return fmt.Errorf("unknown queue method ID: %d", methodID)
	}
}

// handleQueueDeclare handles the queue.declare method
func (s *Server) handleQueueDeclare(conn *protocol.Connection, channelID uint16, payload []byte) error {
	// Deserialize the queue.declare method
	declareMethod := &protocol.QueueDeclareMethod{}
	err := declareMethod.Deserialize(payload)
	if err != nil {
		s.Log.Error("Failed to deserialize queue.declare",
			zap.Error(err),
			zap.String("connection_id", conn.ID),
			zap.Uint16("channel_id", channelID))
		return err
	}

	// AMQP 0.9.1 spec "reserved" rule (on-failure: access-refused 403):
	// Queue names starting with "amq." are reserved. The client MAY declare
	// a queue starting with "amq." if the passive option is set, or the
	// queue already exists. This check only applies to client-provided names,
	// not server-generated names (amq.gen.*).
	if !declareMethod.Passive && isReservedName(declareMethod.Queue) {
		return s.authzChannelError(conn, channelID,
			fmt.Errorf("queue name %q is reserved (spec: amq. prefix)", declareMethod.Queue),
			50, 10)
	}

	// AMQP 0.9.1 spec "default-name" rule: if queue name is empty, the server
	// MUST create a new queue with a unique generated name.
	queueName := declareMethod.Queue
	if queueName == "" {
		queueName = protocol.GenerateQueueName()
	}

	s.Log.Debug("Queue declared",
		zap.String("queue", queueName),
		zap.Bool("durable", declareMethod.Durable),
		zap.Bool("auto_delete", declareMethod.AutoDelete),
		zap.Bool("exclusive", declareMethod.Exclusive))

	// Authorization check: queue.declare requires configure permission on queue
	if err := s.authorize(conn, channelID, interfaces.Operation{
		Action:       interfaces.ActionConfigure,
		ResourceType: interfaces.ResourceQueue,
		Resource:     queueName,
		VHost:        conn.Vhost,
	}); err != nil {
		return s.authzChannelError(conn, channelID, err, 50, 10)
	}

	// Call the broker to declare the queue
	queue, err := s.Broker.DeclareQueue(
		queueName,
		declareMethod.Durable,
		declareMethod.AutoDelete,
		declareMethod.Exclusive,
		declareMethod.Arguments,
	)

	if err != nil {
		// Malformed known x-arguments (SQ-7 policy validation) are a
		// channel-level soft error: 406 PreconditionFailed, keep the
		// connection alive. Mirrors the ErrExchangeTypeMismatch handling in
		// handleExchangeDeclare.
		if errors.Is(err, broker.ErrInvalidQueueArgument) {
			s.sendChannelClose(conn, channelID, amqperrors.PreconditionFailed, err.Error(), 50, 10)
			return nil
		}
		s.Log.Error("Failed to declare queue",
			zap.Error(err),
			zap.String("queue", queueName))
		return err
	}

	if declareMethod.Exclusive {
		if sb, ok := s.Broker.(*StorageBrokerAdapter); ok {
			if !sb.broker.SetQueueOwnerIfFree(queue.Name, conn.ID) {
				replyText := fmt.Sprintf("QUEUE_LOCKED - queue '%s' is exclusive to another connection", queue.Name)
				s.sendChannelClose(conn, channelID, uint16(amqperrors.ResourceLocked), replyText, 50, 10)
				return fmt.Errorf("queue '%s' is exclusive to another connection", queue.Name)
			}
			queue.OwnerConnID = conn.ID
		}
	}

	if val, exists := conn.Channels.Load(channelID); exists {
		ch := val.(*protocol.Channel)
		ch.Mutex.Lock()
		ch.CurrentQueue = queue.Name
		ch.Mutex.Unlock()
	}

	if s.MetricsCollector != nil {
		s.MetricsCollector.RecordQueueDeclared()
	}

	if declareMethod.NoWait {
		return nil
	}

	// message-count must reflect the real READY depth — RabbitMQ returns the
	// count of messages available for delivery (excluding delivered-but-unacked)
	// on every declare, passive or not. The protocol.Queue.MessageCount runtime
	// counter is never maintained, so query the broker's ready count; fall back
	// to 0 for a non-storage broker.
	msgCount := uint32(0)
	consumerCount := uint32(0)
	if sb, ok := s.Broker.(*StorageBrokerAdapter); ok {
		msgCount = sb.broker.GetQueueReadyCount(queue.Name)
		consumerCount = uint32(sb.broker.GetQueueConsumerCount(queue.Name))
	}
	return s.sendQueueDeclareOK(conn, channelID, queue.Name, msgCount, consumerCount)
}

// handleQueueBind handles the queue.bind method
func (s *Server) handleQueueBind(conn *protocol.Connection, channelID uint16, payload []byte) error {
	// Deserialize the queue.bind method
	bindMethod := &protocol.QueueBindMethod{}
	err := bindMethod.Deserialize(payload)
	if err != nil {
		s.Log.Error("Failed to deserialize queue.bind",
			zap.Error(err),
			zap.String("connection_id", conn.ID),
			zap.Uint16("channel_id", channelID))
		return err
	}

	// AMQP 0.9.1 spec "queue-known" rule: resolve empty queue name to the
	// channel's current queue (last declared queue).
	queueName, err := resolveQueueName(conn, channelID, bindMethod.Queue)
	if err != nil {
		return err
	}

	s.Log.Debug("Queue bound",
		zap.String("queue", queueName),
		zap.String("exchange", bindMethod.Exchange),
		zap.String("routing_key", bindMethod.RoutingKey))

	// Authorization check: queue.bind requires write on queue AND read on exchange
	if err := s.authorize(conn, channelID, interfaces.Operation{
		Action:       interfaces.ActionWrite,
		ResourceType: interfaces.ResourceQueue,
		Resource:     queueName,
		VHost:        conn.Vhost,
	}); err != nil {
		return s.authzChannelError(conn, channelID, err, 50, 20)
	}
	if err := s.authorize(conn, channelID, interfaces.Operation{
		Action:       interfaces.ActionRead,
		ResourceType: interfaces.ResourceExchange,
		Resource:     bindMethod.Exchange,
		VHost:        conn.Vhost,
	}); err != nil {
		return s.authzChannelError(conn, channelID, err, 50, 20)
	}

	// Call the broker to bind the queue
	err = s.Broker.BindQueue(
		queueName,
		bindMethod.Exchange,
		bindMethod.RoutingKey,
		bindMethod.Arguments,
	)

	if err != nil {
		s.Log.Error("Failed to bind queue",
			zap.Error(err),
			zap.String("queue", queueName),
			zap.String("exchange", bindMethod.Exchange))
		return err
	}

	// Send queue.bind-ok response
	return s.sendQueueBindOK(conn, channelID)
}

// handleQueueUnbind handles the queue.unbind method
func (s *Server) handleQueueUnbind(conn *protocol.Connection, channelID uint16, payload []byte) error {
	// Deserialize the queue.unbind method
	// We need to create a structure for this, but for now we'll implement a basic approach
	// The queue.unbind method has similar structure to queue.bind but without arguments

	// Create a temporary approach - reuse QueueBindMethod for deserialization since structure is similar
	unbindMethod := &protocol.QueueBindMethod{}
	err := unbindMethod.Deserialize(payload)
	if err != nil {
		s.Log.Error("Failed to deserialize queue.unbind",
			zap.Error(err),
			zap.String("connection_id", conn.ID),
			zap.Uint16("channel_id", channelID))
		return err
	}

	// AMQP 0.9.1 spec "queue-known" rule: resolve empty queue name to the
	// channel's current queue (last declared queue).
	queueName, err := resolveQueueName(conn, channelID, unbindMethod.Queue)
	if err != nil {
		return err
	}

	s.Log.Debug("Queue unbound",
		zap.String("queue", queueName),
		zap.String("exchange", unbindMethod.Exchange),
		zap.String("routing_key", unbindMethod.RoutingKey))

	// Authorization check: queue.unbind requires write on queue AND read on exchange
	if err := s.authorize(conn, channelID, interfaces.Operation{
		Action:       interfaces.ActionWrite,
		ResourceType: interfaces.ResourceQueue,
		Resource:     queueName,
		VHost:        conn.Vhost,
	}); err != nil {
		return s.authzChannelError(conn, channelID, err, 50, 50)
	}
	if err := s.authorize(conn, channelID, interfaces.Operation{
		Action:       interfaces.ActionRead,
		ResourceType: interfaces.ResourceExchange,
		Resource:     unbindMethod.Exchange,
		VHost:        conn.Vhost,
	}); err != nil {
		return s.authzChannelError(conn, channelID, err, 50, 50)
	}

	// Call the broker to unbind the queue
	err = s.Broker.UnbindQueue(
		queueName,
		unbindMethod.Exchange,
		unbindMethod.RoutingKey,
	)

	if err != nil {
		s.Log.Error("Failed to unbind queue",
			zap.Error(err),
			zap.String("queue", queueName),
			zap.String("exchange", unbindMethod.Exchange))
		return err
	}

	// Send queue.unbind-ok response
	return s.sendQueueUnbindOK(conn, channelID)
}

// handleQueuePurge handles the queue.purge method
func (s *Server) handleQueuePurge(conn *protocol.Connection, channelID uint16, payload []byte) error {
	purgeMethod := &protocol.QueuePurgeMethod{}
	err := purgeMethod.Deserialize(payload)
	if err != nil {
		s.Log.Error("Failed to deserialize queue.purge",
			zap.Error(err),
			zap.String("connection_id", conn.ID),
			zap.Uint16("channel_id", channelID))
		return err
	}

	queueName, err := resolveQueueName(conn, channelID, purgeMethod.Queue)
	if err != nil {
		return err
	}

	s.Log.Debug("Queue purge requested",
		zap.String("queue", queueName))

	if err := s.authorize(conn, channelID, interfaces.Operation{
		Action:       interfaces.ActionWrite,
		ResourceType: interfaces.ResourceQueue,
		Resource:     queueName,
		VHost:        conn.Vhost,
	}); err != nil {
		return s.authzChannelError(conn, channelID, err, 50, 30)
	}

	count, err := s.Broker.PurgeQueue(queueName)
	if err != nil {
		s.Log.Error("Failed to purge queue",
			zap.Error(err),
			zap.String("queue", queueName))
		return err
	}

	if !purgeMethod.NoWait {
		return s.sendQueuePurgeOK(conn, channelID, uint32(count))
	}

	return nil
}

// handleQueueDelete handles the queue.delete method
func (s *Server) handleQueueDelete(conn *protocol.Connection, channelID uint16, payload []byte) error {
	// Deserialize the queue.delete method
	deleteMethod := &protocol.QueueDeleteMethod{}
	err := deleteMethod.Deserialize(payload)
	if err != nil {
		s.Log.Error("Failed to deserialize queue.delete",
			zap.Error(err),
			zap.String("connection_id", conn.ID),
			zap.Uint16("channel_id", channelID))
		return err
	}

	// AMQP 0.9.1 spec "queue-known" rule: resolve empty queue name to the
	// channel's current queue (last declared queue).
	queueName, err := resolveQueueName(conn, channelID, deleteMethod.Queue)
	if err != nil {
		return err
	}

	s.Log.Debug("Queue deleted",
		zap.String("queue", queueName),
		zap.Bool("if_unused", deleteMethod.IfUnused),
		zap.Bool("if_empty", deleteMethod.IfEmpty))

	// Authorization check: queue.delete requires configure permission on queue
	if err := s.authorize(conn, channelID, interfaces.Operation{
		Action:       interfaces.ActionConfigure,
		ResourceType: interfaces.ResourceQueue,
		Resource:     queueName,
		VHost:        conn.Vhost,
	}); err != nil {
		return s.authzChannelError(conn, channelID, err, 50, 40)
	}

	if sb, ok := s.Broker.(*StorageBrokerAdapter); ok {
		if ownerID, exists := sb.broker.GetQueueOwner(queueName); exists && ownerID != conn.ID {
			replyText := fmt.Sprintf("QUEUE_LOCKED - queue '%s' is exclusive to another connection", queueName)
			s.sendChannelClose(conn, channelID, uint16(amqperrors.ResourceLocked), replyText, 50, 40)
			return fmt.Errorf("queue '%s' is exclusive to another connection", queueName)
		}
	}

	var consumerTags []string
	if sb, ok := s.Broker.(*StorageBrokerAdapter); ok {
		consumerTags = sb.broker.GetQueueConsumerTags(queueName)
	}

	count, err := s.Broker.DeleteQueue(queueName, deleteMethod.IfUnused, deleteMethod.IfEmpty)
	if err != nil {
		s.Log.Error("Failed to delete queue",
			zap.Error(err),
			zap.String("queue", queueName))
		return err
	}

	if len(consumerTags) > 0 {
		s.notifyConsumersCancelled(consumerTags)
	}

	if val, exists := conn.Channels.Load(channelID); exists {
		ch := val.(*protocol.Channel)
		ch.Mutex.Lock()
		if ch.CurrentQueue == queueName {
			ch.CurrentQueue = ""
		}
		ch.Mutex.Unlock()
	}

	if s.MetricsCollector != nil {
		s.MetricsCollector.RecordQueueDeleted()
	}

	if deleteMethod.NoWait {
		return nil
	}

	return s.sendQueueDeleteOK(conn, channelID, uint32(count))
}

func (s *Server) notifyConsumersCancelled(consumerTags []string) {
	s.Mutex.RLock()
	connections := make([]*protocol.Connection, 0, len(s.Connections))
	for _, conn := range s.Connections {
		connections = append(connections, conn)
	}
	s.Mutex.RUnlock()

	for _, tag := range consumerTags {
		for _, conn := range connections {
			if conn.Closed.Load() {
				continue
			}
			var foundChannel *protocol.Channel
			conn.Channels.Range(func(key, value interface{}) bool {
				ch := value.(*protocol.Channel)
				ch.Mutex.Lock()
				if consumer, exists := ch.Consumers[tag]; exists {
					foundChannel = ch
					close(consumer.Cancel)
					delete(ch.Consumers, tag)
				}
				ch.Mutex.Unlock()
				return foundChannel == nil
			})
			if foundChannel != nil {
				conn.ConsumersDirty.Store(true)
				if err := s.sendBasicCancel(conn, foundChannel.ID, tag); err != nil {
					s.Log.Warn("Failed to send basic.cancel to consumer",
						zap.String("consumer_tag", tag),
						zap.String("connection_id", conn.ID),
						zap.Error(err))
				}
				break
			}
		}
	}
}
